package dao;

import com.mycompany.listacompras.Usuario;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    public void salvar(Usuario usuario) {

        String sql =
                "INSERT INTO usuario(nome, email, senha) VALUES (?, ?, ?)";

        try (
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/lista_compras",
                    "root",
                    "1234"
            );

            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getSenha());

            stmt.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    public boolean login(String email, String senha) {

        String sql =
                "SELECT * FROM usuario WHERE email = ? AND senha = ?";

        try (
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/lista_compras",
                    "root",
                    "1234"
            );

            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {

            stmt.setString(1, email);
            stmt.setString(2, senha);

            ResultSet rs = stmt.executeQuery();

            return rs.next();

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return false;
    }
}
